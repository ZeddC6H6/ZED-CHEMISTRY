/**
 * Gamification System for Zed Chemistry
 * Handles XP, Levels, and Badges using localStorage.
 */

const STATE_KEY = 'zed_chemistry_state';

const LEVEL_THRESHOLDS = [
    0, 100, 300, 600, 1000, 1500, 2100, 2800, 3600, 4500, 5500
];

const DEFAULT_STATE = {
    xp: 0,
    level: 1,
    badges: [], // ['chemist-novice', 'quiz-master', etc.]
    completedQuizzes: []
};

// --- Core Functions ---

function getState() {
    const stored = localStorage.getItem(STATE_KEY);
    return stored ? JSON.parse(stored) : DEFAULT_STATE;
}

function saveState(state) {
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
    updateUI(); // Auto-update UI whenever state changes
}

function addXP(amount) {
    const state = getState();
    state.xp += amount;

    // Check for level up
    const nextLevelXP = LEVEL_THRESHOLDS[state.level];
    if (state.xp >= nextLevelXP) {
        state.level += 1;
        showLevelUpNotification(state.level);
    }

    saveState(state);
    return state;
}

function unlockBadge(badgeId) {
    const state = getState();
    if (!state.badges.includes(badgeId)) {
        state.badges.push(badgeId);
        saveState(state);
        // Could show a notification here
        console.log(`Badge Unlocked: ${badgeId}`);
    }
}

// --- UI Updates ---

function updateUI() {
    const state = getState();

    // Update all elements with data-gamify="xp"
    document.querySelectorAll('[data-gamify="xp"]').forEach(el => {
        el.textContent = state.xp;
    });

    // Update all elements with data-gamify="level"
    document.querySelectorAll('[data-gamify="level"]').forEach(el => {
        el.textContent = state.level;
    });

    // Update progress bars if any
    document.querySelectorAll('[data-gamify="level-progress"]').forEach(el => {
        const currentLevelXP = LEVEL_THRESHOLDS[state.level - 1] || 0;
        const nextLevelXP = LEVEL_THRESHOLDS[state.level] || (currentLevelXP + 1000);
        const progress = ((state.xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
        el.style.width = `${Math.min(100, Math.max(0, progress))}%`;
    });
}

function showLevelUpNotification(newLevel) {
    // Create notification element
    const notif = document.createElement('div');
    notif.className = "fixed top-24 right-4 z-50 bg-white dark:bg-neutral-800 border-2 border-primary rounded-xl shadow-xl p-4 flex items-center gap-4 max-w-sm pointer-events-none";
    notif.innerHTML = `
        <div class="size-12 bg-primary/20 text-primary rounded-full flex items-center justify-center text-2xl animate-bounce">
            🎉
        </div>
        <div>
            <h4 class="font-bold text-neutral-900 dark:text-white text-lg leading-tight">Level Up!</h4>
            <p class="text-neutral-600 dark:text-neutral-400 text-sm">You reached Level <span class="text-primary font-bold text-lg">${newLevel}</span></p>
        </div>
    `;

    document.body.appendChild(notif);

    // Animate with GSAP if available
    if (typeof gsap !== 'undefined') {
        gsap.fromTo(notif,
            { x: 100, opacity: 0 },
            { x: 0, opacity: 1, duration: 0.5, ease: "back.out(1.7)" }
        );

        // Remove after 4 seconds
        gsap.to(notif, {
            x: 100,
            opacity: 0,
            duration: 0.5,
            delay: 4,
            ease: "power2.in",
            onComplete: () => notif.remove()
        });
    } else {
        // Fallback
        setTimeout(() => notif.remove(), 4000);
    }
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    updateUI();
});

// Export for use in other scripts (if using modules, but we are using plain script tags for simplicity)
window.Gamification = {
    addXP,
    getState,
    unlockBadge,
    updateUI
};
