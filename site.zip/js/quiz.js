/**
 * Interactive Quiz Logic
 */

// Sample Questions Data
const QUIZ_DATA = [
    {
        question: "What is the chemical formula for Water?",
        options: ["H2O", "CO2", "O2", "NaCl"],
        correct: 0, // Index of correct option
        xp: 10
    },
    {
        question: "Which gas do plants absorb from the atmosphere?",
        options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
        correct: 1,
        xp: 10
    },
    {
        question: "What is the symbol for Gold?",
        options: ["Ag", "Fe", "Au", "Pb"],
        correct: 2,
        xp: 20
    },
    {
        question: "Which particle has a negative charge?",
        options: ["Proton", "Neutron", "Electron", "Nucleus"],
        correct: 2,
        xp: 15
    },
    {
        question: "What is the pH value of pure water?",
        options: ["0", "7", "14", "1"],
        correct: 1,
        xp: 10
    }
];

let currentQuestionIndex = 0;
let score = 0;
let totalXP = 0;

// DOM Elements
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const progressText = document.getElementById('progress-text');
const progressBar = document.getElementById('progress-bar');
const nextButton = document.getElementById('next-button');

function initQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    totalXP = 0;
    showQuestion(currentQuestionIndex);
}

function showQuestion(index) {
    if (index >= QUIZ_DATA.length) {
        finishQuiz();
        return;
    }

    const data = QUIZ_DATA[index];

    // Update Text
    questionText.textContent = data.question;
    progressText.textContent = `Question ${index + 1} of ${QUIZ_DATA.length}`;

    // Update Progress Bar
    const progressPercent = ((index) / QUIZ_DATA.length) * 100;
    progressBar.style.width = `${progressPercent}%`;

    // Clear and Render Options
    optionsContainer.innerHTML = '';

    data.options.forEach((opt, i) => {
        const label = document.createElement('label');
        label.className = "relative cursor-pointer group block mb-4 opacity-0"; // Start hidden for animation
        label.innerHTML = `
            <input class="peer hidden radio-custom" name="quiz-option" type="radio" value="${i}" />
            <div class="flex items-center gap-4 rounded-xl border-2 border-background-light dark:border-white/10 p-5 transition-all duration-200 peer-checked:border-primary peer-checked:bg-primary/10 hover:border-primary/50 bg-white dark:bg-white/5">
                <div class="flex size-10 items-center justify-center rounded-full bg-background-light dark:bg-white/10 text-[#181711] dark:text-white font-extrabold text-lg group-hover:bg-primary/30">
                    ${String.fromCharCode(65 + i)}
                </div>
                <div class="flex grow flex-col">
                    <p class="text-[#181711] dark:text-white text-xl font-bold leading-none">${opt}</p>
                </div>
                <span class="material-symbols-outlined text-primary opacity-0 peer-checked:opacity-100 transition-opacity">check_circle</span>
            </div>
        `;
        optionsContainer.appendChild(label);
    });

    // GSAP Animations
    if (typeof gsap !== 'undefined') {
        gsap.fromTo("#question-text",
            { y: -20, opacity: 0 },
            { duration: 0.5, y: 0, opacity: 1, ease: "back.out(1.7)" }
        );

        gsap.to("#options-container label", {
            duration: 0.5,
            y: 0,
            opacity: 1,
            stagger: 0.1,
            ease: "power2.out",
            delay: 0.1
        });
    } else {
        // Fallback checks just in case
        document.querySelectorAll("#options-container label").forEach(el => el.classList.remove("opacity-0"));
    }

    // Reset Button
    nextButton.innerHTML = `<span>Submit Answer</span><span class="material-symbols-outlined">check</span>`;
    nextButton.onclick = checkAnswer;
}

function checkAnswer() {
    const selected = document.querySelector('input[name="quiz-option"]:checked');
    if (!selected) {
        alert("Please select an answer!");
        return;
    }

    const selectedIndex = parseInt(selected.value);
    const data = QUIZ_DATA[currentQuestionIndex];
    const isCorrect = selectedIndex === data.correct;

    // Visual Feedback
    const optionCards = optionsContainer.querySelectorAll('.rounded-xl');

    if (isCorrect) {
        optionCards[selectedIndex].classList.remove('peer-checked:bg-primary/10', 'peer-checked:border-primary');
        optionCards[selectedIndex].classList.add('bg-green-100', 'border-green-500', 'dark:bg-green-900/30');
        score++;
        totalXP += data.xp;

        // Instant XP animation could go here
    } else {
        optionCards[selectedIndex].classList.remove('peer-checked:bg-primary/10', 'peer-checked:border-primary');
        optionCards[selectedIndex].classList.add('bg-red-100', 'border-red-500', 'dark:bg-red-900/30');

        // Highlight correct answer
        optionCards[data.correct].classList.add('bg-green-100', 'border-green-500', 'dark:bg-green-900/30');
    }

    // Disable all inputs
    const inputs = optionsContainer.querySelectorAll('input');
    inputs.forEach(input => input.disabled = true);

    // Change button to Next
    nextButton.innerHTML = `<span>Next Question</span><span class="material-symbols-outlined">arrow_forward</span>`;
    nextButton.onclick = () => {
        currentQuestionIndex++;
        showQuestion(currentQuestionIndex);
    };
}

function finishQuiz() {
    // Save results to sessionStorage
    const resultData = {
        score: score,
        totalQuestions: QUIZ_DATA.length,
        xpEarned: totalXP
    };
    sessionStorage.setItem('last_quiz_result', JSON.stringify(resultData));

    // Add XP to global state
    if (window.Gamification) {
        window.Gamification.addXP(totalXP);
    }

    // Redirect
    window.location.href = 'quiz-results.html';
}

// Start
document.addEventListener('DOMContentLoaded', initQuiz);
