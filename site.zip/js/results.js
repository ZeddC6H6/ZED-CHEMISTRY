// results.js

// Ensure Gamification loaded
// (Usually redundant if Gamification is loaded in header, but good practice if modular)

document.addEventListener('DOMContentLoaded', () => {
    // 1. Get results from previous session
    const resultsJSON = sessionStorage.getItem('last_quiz_result');
    if (!resultsJSON) {
        // No results? Maybe redirect to quiz or show placeholders
        console.warn("No quiz results found.");
        return;
    }

    const results = JSON.parse(resultsJSON);

    // 2. Update Score Text
    // Assuming we have an element ID for score text, but the HTML is currently hardcoded "8/10".
    // We need to update HTML to have IDs.
    // For now, let's select by identifying class or assume IDs will be added.

    const scoreDisplay = document.getElementById('score-display');
    if (scoreDisplay) {
        scoreDisplay.textContent = `${results.score}/${results.totalQuestions} Correct!`;
    }

    const xpDisplay = document.getElementById('xp-gained-display');
    if (xpDisplay) {
        xpDisplay.textContent = `+${results.xpEarned} XP`;
    }

    // 3. Update gamification UI in header (if any)
    if (window.Gamification) {
        window.Gamification.updateUI();
    }

    // 4. Fire Celebration Confetti (using GSAP if available)
    if (typeof gsap !== 'undefined') {
        fireConfetti();
    }
});

function fireConfetti() {
    const colors = ['#f4e225', '#ef4444', '#3b82f6', '#22c55e', '#a855f7'];
    const container = document.body;

    for (let i = 0; i < 100; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'fixed w-3 h-3 rounded-sm z-50 pointer-events-none';
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.left = '50%';
        confetti.style.top = '50%';
        container.appendChild(confetti);

        const angle = Math.random() * Math.PI * 2;
        const velocity = 200 + Math.random() * 300;
        const tx = Math.cos(angle) * velocity;
        const ty = Math.sin(angle) * velocity;

        gsap.to(confetti, {
            x: tx,
            y: ty,
            rotation: Math.random() * 720,
            opacity: 0,
            duration: 1.5 + Math.random() * 1.5,
            ease: "power2.out",
            onComplete: () => confetti.remove()
        });
    }
}
