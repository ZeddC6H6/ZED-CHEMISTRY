/**
 * Animations using GSAP
 * Requires GSAP via CDN in HTML
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check if GSAP is loaded
    if (typeof gsap === 'undefined') {
        console.warn('GSAP not loaded.');
        return;
    }

    // 1. Hero Entries (Stagger from bottom)
    gsap.from('.hero-animate', {
        y: 50,
        opacity: 0,
        duration: 1,
        stagger: 0.2,
        ease: 'back.out(1.7)'
    });

    // 2. Cards (Stagger fade in)
    gsap.from('.kid-card-shadow', {
        scale: 0.8,
        opacity: 0,
        duration: 0.8,
        stagger: 0.1,
        delay: 0.5,
        ease: 'power2.out'
    });

    // 3. Floating Bubbles/Icons (Continuous background loop)
    // Select any absolute position icons or add specific class
    gsap.to('.float-icon', {
        y: -10,
        duration: 2,
        yoyo: true,
        repeat: -1,
        ease: 'sine.inOut',
        stagger: {
            each: 0.5,
            from: "random"
        }
    });

    console.log('Animations initialized.');
});
